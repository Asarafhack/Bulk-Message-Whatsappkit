import pywhatkit as kit
import pandas as pd
import time

# Load your contacts from CSV
df = pd.read_csv('contacts.csv', dtype=str)  # Ensure all data is read as strings

# Message to be sent
message = "Hello, this is a bulk message!"

# Delay between messages (in seconds)
delay = 60  # 1 minute delay

# Max messages to send per run (to avoid rapid bulk sending)
max_messages = 5

for index, row in df.head(max_messages).iterrows():
    phone_number = row['Phone Number'].strip()  # Ensure there are no leading/trailing spaces
    
    # Send WhatsApp message
    try:
        kit.sendwhatmsg_instantly(phone_number, message)
        print(f"Message sent to {phone_number}")
    except Exception as e:
        print(f"Failed to send message to {phone_number}: {e}")
    
    # Wait before sending the next message
    time.sleep(delay)

print("Messages sent successfully!")
